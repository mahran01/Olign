import { Stack } from 'expo-router';
import * as React from 'react';
import { Text, View, YStack } from 'tamagui';

interface IDashboardScreenProps {
}

const DashboardScreen: React.FC<IDashboardScreenProps> = (props) => {
    return (
        <YStack>

        </YStack>
    );
};

export default DashboardScreen;
