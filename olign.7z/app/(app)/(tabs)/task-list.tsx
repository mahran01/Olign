import * as React from 'react';
import { Text } from 'tamagui';

interface ITaskListScreenProps {
}

const TaskListScreen: React.FunctionComponent<ITaskListScreenProps> = (props) => {
    return (
        <Text>TASK LIST</Text>
    );
};

export default TaskListScreen;
